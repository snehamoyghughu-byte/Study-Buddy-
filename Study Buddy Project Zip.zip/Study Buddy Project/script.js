const taskForm = document.getElementById('task-form');
const taskInput = document.getElementById('task-input');
const taskList = document.getElementById('task-list');
const taskCount = document.getElementById('task-count');
const startBtn = document.getElementById('start-btn');
const resetBtn = document.getElementById('reset-btn');
const timerDisplay = document.getElementById('timer-display');
const tipText = document.getElementById('tip-text');

let tasks = JSON.parse(localStorage.getItem('study-buddy-tasks')) || [];
let timerDuration = 25 * 60;
let timeLeft = timerDuration;
let timerInterval = null;
let isRunning = false;

const tips = [
  'Focus on one topic at a time to avoid mental overload.',
  'A short break after 25 minutes can improve concentration.',
  'Write down your next step before you begin studying.'
];

function saveTasks() {
  localStorage.setItem('study-buddy-tasks', JSON.stringify(tasks));
}

function renderTasks() {
  if (!tasks.length) {
    taskList.innerHTML = '<li class="task-item">No tasks yet. Add your first study goal.</li>';
    taskCount.textContent = '0 tasks';
    return;
  }

  taskList.innerHTML = '';
  tasks.forEach((task) => {
    const li = document.createElement('li');
    li.className = `task-item${task.completed ? ' completed' : ''}`;

    const span = document.createElement('span');
    span.textContent = task.text;

    const actions = document.createElement('div');
    actions.className = 'task-actions';

    const doneBtn = document.createElement('button');
    doneBtn.className = 'task-btn';
    doneBtn.textContent = task.completed ? 'Undo' : 'Done';
    doneBtn.addEventListener('click', () => toggleTask(task.id));

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'task-btn';
    deleteBtn.textContent = 'Delete';
    deleteBtn.addEventListener('click', () => deleteTask(task.id));

    actions.append(doneBtn, deleteBtn);
    li.append(span, actions);
    taskList.appendChild(li);
  });

  const remaining = tasks.filter((task) => !task.completed).length;
  taskCount.textContent = `${remaining} active task${remaining === 1 ? '' : 's'}`;
}

function addTask(text) {
  const trimmed = text.trim();
  if (!trimmed) return;

  tasks.unshift({ id: Date.now(), text: trimmed, completed: false });
  saveTasks();
  renderTasks();
}

function toggleTask(id) {
  tasks = tasks.map((task) =>
    task.id === id ? { ...task, completed: !task.completed } : task
  );
  saveTasks();
  renderTasks();
}

function deleteTask(id) {
  tasks = tasks.filter((task) => task.id !== id);
  saveTasks();
  renderTasks();
}

function updateTimerDisplay() {
  const mins = String(Math.floor(timeLeft / 60)).padStart(2, '0');
  const secs = String(timeLeft % 60).padStart(2, '0');
  timerDisplay.textContent = `${mins}:${secs}`;
}

function startTimer() {
  if (isRunning) {
    clearInterval(timerInterval);
    isRunning = false;
    startBtn.textContent = 'Start';
    return;
  }

  isRunning = true;
  startBtn.textContent = 'Pause';
  timerInterval = setInterval(() => {
    timeLeft -= 1;
    updateTimerDisplay();

    if (timeLeft <= 0) {
      clearInterval(timerInterval);
      isRunning = false;
      startBtn.textContent = 'Start';
      timeLeft = timerDuration;
      updateTimerDisplay();
      alert('Focus session complete! Time for a short break.');
    }
  }, 1000);
}

function resetTimer() {
  clearInterval(timerInterval);
  isRunning = false;
  timeLeft = timerDuration;
  startBtn.textContent = 'Start';
  updateTimerDisplay();
}

function pickRandomTip() {
  tipText.textContent = tips[Math.floor(Math.random() * tips.length)];
}

taskForm.addEventListener('submit', (event) => {
  event.preventDefault();
  addTask(taskInput.value);
  taskInput.value = '';
});

startBtn.addEventListener('click', startTimer);
resetBtn.addEventListener('click', resetTimer);

renderTasks();
pickRandomTip();
updateTimerDisplay();
